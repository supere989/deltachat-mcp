#!/bin/bash
# Simple Portable Launcher

echo "🚀 Delta Chat MCP Server (Portable)"
echo ""

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 required"
    exit 1
fi

# Configuration
if [ ! -f "config.env" ]; then
    echo "Please run: python configure.py"
    exit 1
fi

# Load config and start
source config.env
python3 -m deltachat_mcp.server
