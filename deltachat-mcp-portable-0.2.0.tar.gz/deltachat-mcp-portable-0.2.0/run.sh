#!/bin/bash
# Simple Portable Launcher

echo "🚀 Delta Chat MCP Server (Portable)"
echo ""
echo "Choose interface:"
echo "1) 🖥️ Desktop GUI (recommended)"
echo "2) 💻 Command Line"
echo ""
read -p "Enter choice (1 or 2): " choice

case $choice in
    1)
        echo "🖥️ Starting Desktop GUI..."
        python3 deltachat_mcp_gui.py
        ;;
    2)
        echo "💻 Starting Command Line Interface..."
        if [ ! -f "config.env" ]; then
            echo "Please run: python configure.py"
            exit 1
        fi
        source config.env
        python3 -m deltachat_mcp.server
        ;;
    *)
        echo "Invalid choice. Starting GUI by default..."
        python3 deltachat_mcp_gui.py
        ;;
esac
